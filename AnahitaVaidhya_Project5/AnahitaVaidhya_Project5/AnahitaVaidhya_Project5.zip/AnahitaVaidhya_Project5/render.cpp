//
//  main.cpp
//  AnahitaVaidhya_Project5
//
//  Created by Anahita Vaidhya on 11/14/23.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include <cctype>
#include <cstring>
#include <iostream>
using namespace std;

bool isWhitespace(char ch){
    return (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r');
}

int render(int lineLength, istream& inf, ostream& outf);

void testRender(int lineLength, const char input[], const char expectedOutput[], int expectedReturnValue)
{
    istringstream iss(input);
    ostringstream oss;
    ostringstream dummy;
    streambuf* origCout = cout.rdbuf(dummy.rdbuf());
    int retval = render(lineLength, iss, oss);
    cout.rdbuf(origCout);
    if ( ! dummy.str().empty())
        cerr << "WROTE TO COUT INSTEAD OF THIRD PARAMETER FOR: " << input << endl;
    else if (retval != expectedReturnValue)
        cerr << "WRONG RETURN VALUE FOR: " << input << endl;
    else if (retval == 2)
    {
        if ( ! oss.str().empty())
            cerr << "WROTE OUTPUT WHEN LINELENGTH IS " << lineLength << endl;
    }
    else if (oss.str() != expectedOutput)
        cerr << "WRONG RESULT FOR: " << input << endl;
}

int render(int lineLength, istream& inf, ostream& outf) {
    //Variables
    const int MAX = 181;
    char line[MAX];
    size_t remaining = lineLength;
    size_t tokenLength;
    int retVal = 0;
    size_t muchLeft;
    bool isHyphen = false;
    bool first = true;
    bool firstAfter = false;
    bool punc = false;
    
    //Return 2 if the desired maximum length < 1
    if(lineLength < 1){
        return 2;
    }
    
    //Get line by line
    while (inf.getline(line, MAX))
    {
        //Separates each word into tokens split by whitespace
        const char* delimiters = " \f\n\r\t\v"; // Add space to delimiters
        
        // Skip leading whitespace characters
        char* nonWhitespace = line;
        while (*nonWhitespace && strchr(delimiters, *nonWhitespace))
        {
            nonWhitespace++;
        }
        
        // Tokenize using strtok
        char* token = strtok(nonWhitespace, delimiters);
        
        //Loops through each word
        while (token)
        {
            // Calculate the length of the current token
            tokenLength = strlen(token);
            
            //Checks NULL
            if(token == NULL){
                break;
                //what if +1 is greater but -1 is less than? test case? regarding first if
            }
            //Checks Punctuation
            if (strchr(token, '.') || strchr(token, '?') || strchr(token, '!') || strchr(token, ':')){
                punc = true;
            }
            if(strcmp(token, "@P@") == 0){
                if (!first) {
                    outf << endl; // Separate paragraphs with an empty line
                    first = true;
                }
                remaining = lineLength;
            }
            //Checks Hyphen
            if (strchr(token, '-')){
                isHyphen = true;
            }
            
            //Checks if the word has a punctuation
            if(punc)
            {
                //Checks if it is a first word and token can fit in line
                if(first && tokenLength < lineLength){
                    outf << token;
                    remaining = lineLength;
                    remaining -= (tokenLength);
                    first = false;
                    firstAfter = true;
                    punc = true;
                //Checks if it is a first word and token can't fit in line so gotta wrap
                } else if(first && tokenLength > lineLength){
                    if(tokenLength % lineLength == 0){
                        first = true;
                        firstAfter = false;
                        //punc = false;
                    } else {
                        first = false;
                        firstAfter = true;
                        punc = false;
                    }
                    //wrap
                    while(tokenLength > lineLength){
                        for(int i = 0; i < lineLength; i++){
                            outf << token[i];
                            remaining -= 1;
                        }
                        outf << endl;
                        token += lineLength;
                        tokenLength -= lineLength;
                    }
                    outf << token;
                    remaining = lineLength;
                    remaining -= tokenLength;
                    retVal = 1;
                //Checks if word is less than remaining even with spaces
                } else if ((tokenLength+2 < remaining) || (tokenLength+1 < remaining))
                {
                    if (first && !firstAfter){ //firstAfter is true only when you can write on same line after punctuation, first is true on new line, punc is true after punctuation
                        outf << token;
                        first = false;
                        firstAfter = false;
                        punc = false;
                        remaining -= tokenLength;
                    } else if (!first && firstAfter){
                        outf << "  " << token;
                        first = false;
                        firstAfter = false;
                        punc = false;
                        remaining -= tokenLength+2;
                    } else {
                        outf << " " << token;
                        first = false;
                        firstAfter = true;
                        punc = true;
                        remaining -= tokenLength+1;
                    }
                //Checks if word is equal to remaining
                } else if (tokenLength+1 == remaining)
                {
                    if (first && !firstAfter){
                        outf << token << endl;
                        first = false;
                        firstAfter = false;
                        punc = false;
                        remaining -= tokenLength;
                    }
                    else{
                        outf << " " << token << endl;
                        first = true;
                        firstAfter = false;
                        punc = false;
                        remaining -= tokenLength;
                    }
                }
                //Checks if it is not a first word and is the firstAfter a punctuation and token is exactly remaining
                else if (!first && firstAfter && tokenLength+2 == remaining)
                {
                    outf << "  " << token << endl;
                    first = true;
                    firstAfter = false;
                    punc = false;
                    remaining -= tokenLength+2;
                //Checks if token has to wrap
                } else if (tokenLength > lineLength){
                    if(!first){
                        outf << " ";
                    } else if (firstAfter){
                        outf << "  ";
                    }
                    muchLeft = remaining;
                    //wrap
                    while(tokenLength > lineLength){
                        for(int i = 0; i < remaining; i++){ //remaining
                            outf << token[i];
                            muchLeft--;
                        }
                        outf << endl;
                        token += remaining;
                        tokenLength -= remaining;
                    }
                    remaining = muchLeft;
                    outf << token;
                    firstAfter = true;
                    retVal = 1;
                //Checks if token has to go on next line
                } else if ((tokenLength+1 > remaining)) //added a +1
                {
                    if(first){
                        outf << endl << token;
                        first = false;
                        remaining = lineLength;
                        remaining -= tokenLength; //why +1?
                    } else {
                        outf << endl << token;
                        remaining = lineLength;
                        remaining -= (tokenLength);
                        firstAfter = true; //changed this check it out
                        punc = true;
                        first = false;
                    }
                }
            //If not punctuation
            } else {
                //Checks if token is first and less than line length
                if(first && tokenLength < lineLength){
                    outf << token;
                    remaining = lineLength;
                    remaining -= (tokenLength);
                    first = false;
                //Checks if token is first and greater than line length so we can wrap
                } else if(first && tokenLength > lineLength){
                    if(tokenLength % lineLength == 0){
                        first = true;
                    } else {
                        first = false;
                    }
                    //Wrap
                    while(tokenLength > lineLength){
                        for(int i = 0; i < lineLength; i++){
                            outf << token[i];
                            remaining -= 1;
                        }
                        outf << endl;
                        token += lineLength;
                        tokenLength -= lineLength;
                    }
                    outf << token;
                    remaining = lineLength;
                    remaining -= tokenLength;
                    retVal = 1;
                //check if space and token length can fit in remaining
                } else {
                    if (tokenLength+1 < remaining){
                        outf << " " << token;
                        remaining -= (tokenLength+1);
                    }
                    //check if space and token length can fit in remaining
                    else if (tokenLength+1 == remaining){
                        outf << " " << token << endl;
                        remaining = lineLength;
                        first = true;
                    //check if space and token length have to wrap
                    } else if (tokenLength > lineLength){
                        muchLeft = remaining;
                        //wrap
                        while(tokenLength > lineLength){
                            for(int i = 0; i < remaining; i++){
                                outf << token[i];
                            }
                            outf << endl;
                            token += remaining;
                            tokenLength -= remaining;
                        }
                        remaining = muchLeft;
                        outf << token;
                        retVal = 1;
                    //check if space and token length are greater than remaining so write on a new line
                    } else if (tokenLength+1 > remaining){
                        outf << endl << token;
                        remaining = lineLength;
                        remaining -= (tokenLength);
                    }
                }
            }
                // Get the next token
                token = strtok(nullptr, delimiters);
                
        }
            //Checks for end of file
            if(inf.eof()){
                outf << endl;
            }
        }
        //Returns Value
        return retVal;
    }
    
    
int main()
    {
        testRender(7, "This\n\t\tis a\ntest\n", "This is\na test\n", 0);
        testRender(8, "  This is a test  \n", "This is\na test\n", 0);
        testRender(6, "Testing it\n", "Testin\ng it\n", 1);
        testRender(-5, "irrelevant", "irrelevant", 2);
        cerr << "Tests complete" << endl;
    }
    // /Users/anahitavaidhya/Desktop/UCLA/CS31/AnahitaVaidhya_Project5/data.rtf
    /*
     
     //code that never worked :(
     outf << "2:tokenLength=" << tokenLength << " remaining=" <<remaining;
     if ((tokenLength+2 < remaining) || (tokenLength+1 < remaining))
     {
     if (punc){
     firstAfter = true;
     first = false;
     }
     
     if (first && !firstAfter && !punc){ //firstAfter is true only when you can write on same line after punctuation, first is true on new line, punc is true after punctuation
     outf << token;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength;
     } else if (first && !firstAfter && punc){
     outf << token;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength;
     } else if (!first && firstAfter && punc){
     outf << "  " << token;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength+2;
     }
     
     } else if((tokenLength+2 == remaining) || (tokenLength+1 == remaining)){
     firstAfter = false;
     first = true;
     
     if (first && !firstAfter && !punc){
     outf << token << endl;
     first = true;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength;
     } else if (first && !firstAfter && punc){
     outf << token << endl;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength;
     } else if (!first && firstAfter && punc){
     outf << "  " << token << endl;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength+2;
     } else if (strchr(token, '.') || strchr(token, '?') || strchr(token, '!') || strchr(token, ':')){
     outf << " " << token << endl;
     remaining = lineLength;
     remaining -= (tokenLength);
     first = true;
     punc = true;
     } else if((tokenLength + 2 == remaining) && punc){
     outf << "  " << token << endl;
     remaining = lineLength;
     remaining -= tokenLength+2;
     punc = false;
     } else {
     outf << " " << token << endl;
     remaining = lineLength;
     remaining -= (tokenLength+1); //(+1) ??
     first = true;
     }
     } else if ((tokenLength > remaining)){
     
     
     if(first){
     outf << endl << token;
     first = false;
     remaining = lineLength;
     remaining -= tokenLength; //why +1?
     } else if (strchr(token, '.') || strchr(token, '?') || strchr(token, '!') || strchr(token, ':')){
     outf << endl << token;
     remaining = lineLength;
     remaining -= (tokenLength);
     firstAfter = true;
     punc = true;
     first = false;
     } else if((tokenLength > remaining) && punc){
     outf << endl << token;
     remaining = lineLength;
     remaining -= tokenLength;
     firstAfter = false;
     punc = false;
     first = false;
     } else {
     outf << endl << token;
     remaining = lineLength;
     remaining -= (tokenLength);
     first = false;
     punc = false;
     first = false;
     }
     
     }
     if (first && !firstAfter && !punc){ //firstAfter is true only when you can write on same line after punctuation, first is true on new line, punc is true after punctuation
     outf << token;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength;
     } else if (first && !firstAfter && punc){
     outf << token;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength;
     } else if (!first && firstAfter && punc){
     outf << "  " << token;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength+2;
     }
     //why can't first have punctuation? figure that out afterwards
     else if (strchr(token, '.') || strchr(token, '?') || strchr(token, '!') || strchr(token, ':')){
     //check for last word in line and if it is last word, don't add spaces (figure!!)
     outf << " " << token;
     remaining -= (tokenLength+1);
     firstAfter = true;
     punc = true;
     first = false;
     } else if((tokenLength + 2 <= remaining) && punc){
     outf << "  " << token;
     remaining -= tokenLength + 2;
     punc = false;
     firstAfter = false;
     } else if ((tokenLength + 2 > remaining) && punc){
     outf << endl << token;
     remaining = lineLength;
     remaining -= tokenLength;
     punc = false;
     first = false;
     firstAfter = false;
     } else {
     outf << " " << token;
     remaining -= (tokenLength+1);
     //maybe only count the space before
     //make sure it is not the last in the line (not two spaces at the end)
     }
     } else if ((tokenLength > remaining)){
     if(first){
     outf << endl << token;
     first = false;
     remaining = lineLength;
     remaining -= tokenLength; //why +1?
     } else if (strchr(token, '.') || strchr(token, '?') || strchr(token, '!') || strchr(token, ':')){
     outf << endl << token;
     remaining = lineLength;
     remaining -= (tokenLength);
     firstAfter = true;
     punc = true;
     first = false;
     } else if((tokenLength > remaining) && punc){
     outf << endl << token;
     remaining = lineLength;
     remaining -= tokenLength;
     firstAfter = false;
     punc = false;
     first = false;
     } else {
     outf << endl << token;
     remaining = lineLength;
     remaining -= (tokenLength);
     first = false;
     punc = false;
     first = false;
     }
     } else if ((tokenLength+2 == remaining) || (tokenLength+1 == remaining)) {
     if (first && !firstAfter && !punc){
     outf << token << endl;
     first = true;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength;
     } else if (first && !firstAfter && punc){
     outf << token << endl;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength;
     } else if (!first && firstAfter && punc){
     outf << "  " << token << endl;
     first = false;
     firstAfter = false;
     punc = false;
     remaining -= tokenLength+2;
     } else if (strchr(token, '.') || strchr(token, '?') || strchr(token, '!') || strchr(token, ':')){
     outf << " " << token << endl;
     remaining = lineLength;
     remaining -= (tokenLength);
     first = true;
     punc = true;
     } else if((tokenLength + 2 == remaining) && punc){
     outf << "  " << token << endl;
     remaining = lineLength;
     remaining -= tokenLength+2;
     punc = false;
     } else {
     outf << " " << token << endl;
     remaining = lineLength;
     remaining -= (tokenLength+1); //(+1) ??
     first = true;
     }
     }*/
    
    //if remaining = 0, set remaining to lineLength again

//@P@
/*if(strcmp(token, "@P@") == 0){
     if (!first) {
         outf << endl; // Separate paragraphs with an empty line
     } else {
         //remaining = lineLength;
         first = true;
     }
    remaining = lineLength;
    first = true;
// Handle paragraph break
if (first) {
 outf << endl; // Separate paragraphs with an empty line
 remaining = lineLength;
 first = true;
 } else {
 outf << endl;
 remaining = lineLength;
 remaining = lineLength;
 first = true;
 }
} else {
 outf << endl;
 remaining = lineLength;
 }*/


/*if(numChars < (lineLength - 1)){
 if(numChars)
 }
 
 if(isWhitespace(ch)){
 outf << ' ';
 }
 if(strcmp(word, " @P@ ")){
 outf << endl;
 }
 if(strchr(word, '.') || strchr(word, '?') || strchr(word, '!') || strchr(word, ':')){
 outf << ch << ' ' << ' ';
 }
 if(isalpha(ch)){
 outf << ch;
 }
 if(total > lineLength){
 //strcpy(line, word);
 outf << '\n';
 }*/

/*outf << word;
 //Return 2 if the desired maximum length < 1
 if(lineLength < 1){
 return 2;
 }
 }
 return 0;
 }*/

/*if(isHyphen){
 if(tokenLength <= remaining){
 for(int i = 0; i < tokenLength; i++){
 outf << token[i];
 remaining -= 1;
 }
 } else if (tokenLength > remaining){
 while(tokenLength > lineLength){
 for(int i = 0; i < lineLength; i++){
 outf << token[i];
 remaining -=1;
 }
 if(tokenLength)
 //if(first  && first after @P@ ){
 //outf << token[count];
 //new line for an
 //make a signal earlier to see if it was first word of para, or if previous is @P@
 //decide in next token whether you should start newLine
 //}
 }
 for(int j = 0; j < lineLength; j++){
 if(remaining == 0){
 outf << endl;
 remaining = lineLength;
 
 } else if (tokenLength != 0 && remaining == 0){
 outf << token[j];
 } else {
 outf << token[j];
 remaining -= 1;
 }//make sure hyphen is before ending new line
 }
 }*/

//outf << token[i];
//remaining -= 1;
//if((remaining-1) == 0 && isalnum(token[i+1])){
// outf << token << endl;
//}
//}
/*lineLength = 5
 birth-day
 birth
 -day
 
 bir-day
 bir-
 day
 
 bir-dayshko
 bir-
 daysh
 ko
 
 */

//const char* deHyphen = "-"; // Add space to delimiters
//char* hyphen = strtok(nonWhitespace, deHyphen);

/*if (strchr(token, '-')){
 while(hyphen){
 if(first){
 outf << hyphen;
 first = false;
 }
 outf << "-" << hyphen;
 hyphen = strtok(nullptr, delimiters);
 }
 }*/

/*char* forHyphen = "";
strcpy(forHyphen, nonWhitespace);*/

//char* nextTokenPos = strtok(nullptr, delimiters);
//size_t nextTokenLength = (nextTokenPos) ? strlen(nextTokenPos) : 0;
