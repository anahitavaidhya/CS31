//
//  array.cpp
//  AnahitaVaidhya_Project4
//
//  Created by Anahita Vaidhya on 11/6/23.
//

//Libraries and Namespaces
#include <iostream>
#include <cctype>
#include <string>
#include <cassert>
using namespace std;

/*all functions that return an int must return −1 if they are passed any bad arguments (e.g. a negative array size, or a position that would require looking at the contents of an element past the last element we're interested in). Unless otherwise noted, passing 0 to the function as the array size is not itself an error; it merely indicates the function should examine no elements of the array.*/

//Reduplicate Function
int reduplicate(string a[], int n){
    //Check if arguments are valid
    if(n < 0){
        return -1;
    }
    
    //For loop to duplicate each index in the array
    for(int i = 0; i < n; i++){
        a[i] = a[i] + a[i];
    }
    
    return n;
}

int locate(const string a[], int n, string target){
    //Check if valid argument
    if(n < 0){
        return -1;
    }
    
    //For loop to check if there is any index in the array equal to target (returns smallest index)
    for(int i = 0; i < n; i++){
        if(a[i] == target){
            return i;
        }
    }
    
    //If no string equal to target
    return -1;
}

int locationOfMax(const string a[], int n){
    //Check if valid arguments passed
    if(n <= 0){
        return -1;
    }
    
    //Variables
    string store = "";
    int minInd = 0;
    int pos = 0;
    bool isNotRepeat=false;
    
    //Check every index to see which one is the latest in alphabetic order
    for(int i = pos; i < n; i=i+pos){
        for(int j = i + 1; j < n; j++){
            if(a[i] < a[j]){
                minInd = j;
            } else if (a[i] == a[j] && isNotRepeat==false){
                minInd = i;
                pos = j;
                isNotRepeat = true;
                break;
            } else if (a[i] > a[j]) {
                if (isNotRepeat == false)
                {
                    minInd = i;
                }
                pos = i;
            }
        }
    }
    
    return minInd;
}

int circleLeft(string a[], int n, int pos){
    //Variables
    string store = a[pos];
    string temp = "";
    
    //Check if arguments are correct
    if(n <= 0){
        return -1;
    }
    
    //Moves each index to the left
    for(int i = pos; i < n-1; i++){
        a[i] = a[i+1];
    }
    //Sets last index to position
    a[n-1] = store;
    
    return pos;
}

int enumerateRuns(const string a[], int n){
    //Variables
    int count = 0;
    int pos = 0;
    bool isCounted = false;
    
    //Check if arguments are correct
    if(n <= 0){
        return -1;
    }
    
    //Running two loops to check for new one or more consecutive items
    for(int i = pos; i < n; i++){
        for(int j = pos + 1; j < n; j++){
            //New run
            if(a[i] != a[j]){
                count++;
                pos = j;
                break;
            //New run when same element first time
            } else if (a[i] == a[j] && isCounted == false){
                isCounted = true;
                count++;
                pos = j;
                break;
            }
            //Don't count because same run
            else if (a[i] == a[j] && isCounted == true){
                pos = j;
                break;
            }
        }
        
    }
    return count;
}

int flip(string a[], int n){
    //Variables
    string store = "";
    
    //Check if arguments are valid
    if(n <= 0){
        return -1;
    }
    
    //Run through half the array and flip values
    for(int i = 0; i < n/2; i++){
        store = a[i];
        a[i] = a[n-(i+1)];
        a[n-(i+1)] = store;
    }
    
    return n;
}

int locateDifference(const string a1[], int n1, const string a2[], int n2){
    //Check if n1 is valid
    if(n1 <= 0){
        return -1;
    }
    //Check if n2 is valid
    if(n2 <= 0){
        return -1;
    }
    
    //Run through only n1 times to check for differences
    if(n1 < n2){
        for(int i = 0; i < n1; i++){
            if(a1[i] != a2[i])
                return i;
        }
    //Run through n2 times to check for differences
    } else if (n1 > n2){
        for(int i = 0; i < n2; i++){
            if(a1[i] != a2[i])
                return i;
        }
    //Run through either n1 or n2 times, doesn't matter bc =, to check for differences
    } else if (n1 == n2){
        for(int i = 0; i < n2; i++){
            if(a1[i] != a2[i])
                return i;
            }
    }
    
    //Return whichever value of n1 and n2 is less than or equal to the other
    if(n1 <= n2){
        return n1;
    } else {
        return n2;
    }
    
    return 0;
}

int subsequence(const string a1[], int n1, const string a2[], int n2)
{
    //Variables
    int count = 0;
    int store = 0;
    bool sameStrVal = true;
    //Check if n1 is valid
    if(n1 <= 0){
        return -1;
    }
    //Check if n2 is valid
    if(n2 <= 0){
        return -1;
    }
    
    //Run through only n1 times to check for consecutive and identical
    if(n1 < n2){
        for(int i = 0; i < n1; i++){
            for(int j = 0; j < n1; j++){
                if(a1[i] != a2[j]){
                    sameStrVal = false;
                    //store = i;
                    //count++;
                    
                    cout << " less a1[" << i << "]=" << a1[i] << " : a2[" << j << "]="  << a2[j];
                    break;
                } else if (a1[i] == a2[j]){
                    sameStrVal = true;
                    //i=j;
                }
            }
            if(sameStrVal){
                return i;
            }
        }
    //Run through only n2 times to check for consecutive and identical
    } else if (n1 > n2){
        for(int i = 0; i < n1-n2; i++){
            for(int j = 0; j < n2; j++){
                if(a1[i+j] != a2[j]){
                    sameStrVal = false;
                    //store = i;
                    //count++;
                    cout << " greater a1[" << i << "]=" << a1[i] << " : a2[" << j << "]="  << a2[j];
                    break;
                } else if (a1[i] == a2[j]){
                    sameStrVal = true;
                    //i=j;
                }
                
            }
            if(sameStrVal){
                return i;
            }
        }
    //Run through either n1 or n2 times to check for consecutive and identical
    } else if (n1 == n2){
        for(int i = 0; i < n1; i++){
            if(a1[i] == a2[i]){
                sameStrVal = true;
                //store = i;
                //count++;
                break;
            }
            if(sameStrVal){
                return i;
            }
        }
        
    }
    
    //cout << count << endl;
    if(count > 0){
        //cout << "in store :" << store << endl;
        return store;
    } else {
        return -1;
    }
}

int locateAny(const string a1[], int n1, const string a2[], int n2){
    //Check if n1 is valid
    if(n1 <= 0){
        return -1;
    }
    //Check if n2 is valid
    if(n2 <= 0){
        return -1;
    }
    
    //Go through loop to check if any of the a1 values are equal to a2
    for(int i = 0; i < n1; i++){
        for(int j = 0; j < n2; j++){
            if(a1[i] == a2[j]){
                return i;
            }
        }
    }
    //None are equal
    return -1;
}

int divide(string a[], int n, string divider){
    //Variables
    string store = "";
    int count = 1;
    int ind = 0;
    
    //Check if arguments are valid
    if(n <= 0){
        return -1;
    }
    
    //While loop goes through multiple times until the array is sorted so that it's divided properly
    while(count >= 1){
        count = 0;
        for(int i = 0; i < n-1; i++){
            if(a[i] > divider && a[i+1] < divider){
                store = a[i];
                a[i] = a[i+1];
                a[i+1] = store;
                count++;
            }
        }
    }
    
    //Checking for the element when a[i] is greater than divider and returning that OR nothing divided and returns n
    for(int i = 0; i < n; i++){
        if(a[i] > divider){
            ind = i;
            break;
        } else {
            ind = n;
        }
    }

    return ind;
}


int main() {
    string h[7] = { "nikki", "ron", "asa", "vivek", "", "chris", "donald" };
            assert(locate(h, 7, "chris") == 5);
            assert(locate(h, 7, "asa") == 2);
            assert(locate(h, 2, "asa") == -1);
            assert(locationOfMax(h, 7) == 3);

            string g[4] = { "nikki", "ron", "chris", "tim" };
            assert(locateDifference(h, 4, g, 4) == 2);
            assert(circleLeft(g, 4, 1) == 1 && g[1] == "chris" && g[3] == "ron");

            string c[4] = { "ma", "can", "tu", "do" };
            assert(reduplicate(c, 4) == 4 && c[0] == "mama" && c[3] == "dodo");

            string e[4] = { "asa", "vivek", "", "chris" };
            assert(subsequence(h, 7, e, 4) == 2);

            string d[5] = { "ron", "ron", "ron", "chris", "chris" };
            assert(enumerateRuns(d, 5) == 2);
        
            string f[3] = { "vivek", "asa", "tim" };
            assert(locateAny(h, 7, f, 3) == 2);
            assert(flip(f, 3) == 3 && f[0] == "tim" && f[2] == "vivek");
        
            assert(divide(h, 7, "donald") == 3);
        
            cout << "All tests succeeded" << endl;
}

